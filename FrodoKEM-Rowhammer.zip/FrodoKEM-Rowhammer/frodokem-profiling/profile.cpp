#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <math.h>
#include <vector>
#include <algorithm>
#include <sys/sysinfo.h>
#include <sys/mman.h>
#include <assert.h>
#include <fcntl.h>
#include <string>
#include <sstream>
#include <map>


#define MAX_LINE_LENGTH 2000

#define TEST_ITERATIONS 10
#define PAGE_SIZE 4096
#define TIME_BETWEEN_ITERATIONS 100000
#define HAMMER_ITERATIONS 1
#define TOGGLES 3000000
#define NUM_PATTERNS 4
#define RISK_THRESHOLD 0


#define E_COLUMN 8
#define E_ROW 640
#define E_LENGTH (E_COLUMN * E_ROW)
#define MAX_BITS 16



#define POSITION_BONUS 10


#define MAX_POSITION 9

using namespace std;

enum Pattern { zero_zero_zero, zero_zero_one, one_zero_zero, one_zero_one };

struct PageCandidate {
    uint32_t pageNumber = 0;
    uint32_t abovePage = 0;
    uint32_t belowPage = 0;

    uint8_t* pageVA;
    uint8_t* aboveVA[2];
    uint8_t* belowVA[2];

    int bitPositions[MAX_BITS];
    int score;
    int totalBitFlips;
};

struct PageData {
    uint16_t data[PAGE_SIZE / 2] = {0};
    uint16_t aboveData[PAGE_SIZE / 2] = {0};
    uint16_t belowData[PAGE_SIZE / 2] = {0};
};

struct PageSuppression {
    int patternData[PAGE_SIZE / 2][MAX_BITS][NUM_PATTERNS] = {0};
};


size_t mem_size;
char *memory;
double fraction_of_physical_memory = 1.05;



uint64_t GetPhysicalMemorySize() {
    struct sysinfo info;
    sysinfo(&info);
    return (size_t) info.totalram * (size_t) info.mem_unit;
}


void setupMapping() {
    mem_size = (size_t) (((GetPhysicalMemorySize()) *
                          fraction_of_physical_memory));


    printf("MemorySize: %zx\n", mem_size);


    memory = (char *) mmap(NULL, mem_size, PROT_READ | PROT_WRITE,
                           MAP_POPULATE | MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);

    assert(memory != MAP_FAILED);

    for(size_t i = 0; i < mem_size; i++) {
	    memory[i] = 77 + i;
    }

    printf("Finished setting up mapping...\n");
}


void fillMemory(uint8_t* victimVA, uint8_t* aboveVA, uint8_t* belowVA) {
    memset((void *) victimVA, 0x00, PAGE_SIZE);

    uint8_t lowerBits = 0x00;
    uint8_t upperBits = 0x01;
    for(int i = 0; i < PAGE_SIZE; i++) {
        if(i % 2 == 0) {
            memset((void *) (aboveVA + i), lowerBits, 1);
            memset((void *) (belowVA + i), lowerBits, 1);
        } else {
            memset((void *) (aboveVA + i), upperBits, 1);
            memset((void *) (belowVA + i), upperBits, 1);
        }
    }
}


uint64_t getPage(uint8_t* virtual_address) {
    int pagemap = open("/proc/self/pagemap", O_RDONLY);
    assert(pagemap != -1);

    uint64_t value;
    int got = pread(pagemap, &value, 8, (reinterpret_cast<uintptr_t>(virtual_address) / 0x1000) * 8);
    assert(got == 8);
    uint64_t page_frame_number = value & ((1ULL << 54) - 1);
    assert(page_frame_number != 0);
    close(pagemap);
    return page_frame_number;
}


int findPosition(vector<PageCandidate> &pages, uint32_t pageNumber) {
    for(int i = 0; i < pages.size(); i++) {
        if(pageNumber == pages[i].pageNumber) {
            return i;
        }
    }
    return -1;

}

int convertHexArrayToInt(char* offset) {
    long number = strtol(offset, NULL, 16);
    return (int)number;
}


int hex2int(char ch)
{
    if (ch >= '0' && ch <= '9')
        return ch - '0';
    if (ch >= 'A' && ch <= 'F')
        return ch - 'A' + 10;
    if (ch >= 'a' && ch <= 'f')
        return ch - 'a' + 10;
    return -1;
}



void calculateScore(PageCandidate &candidate) {
    candidate.score += (candidate.bitPositions[8] + 1) * POSITION_BONUS;
}


bool compareByScore(const PageCandidate &a, const PageCandidate &b)
{
    return a.score > b.score;
}



void getCandidatePages(char *fileName, vector<PageCandidate> &pages) {
    FILE *fptr;
    char line[MAX_LINE_LENGTH] = {0};
    unsigned int line_count = 0;
    fptr = fopen(fileName, "r");
    if(fptr == NULL) {
        printf("File failed to open.\n");
        exit(1);
    }

    while (fgets(line, MAX_LINE_LENGTH, fptr))
    {

        if(strstr(line, "Found")) {

            char lineCopy[MAX_LINE_LENGTH];
            strcpy(lineCopy, line);


            char* cursor = strstr(lineCopy, "0x");
            char bitsValue[16];
            memcpy(bitsValue, cursor + 2, 16);


            cursor = strstr(cursor, "(");
            char* start = cursor;
            cursor = strstr(cursor, ")");
            char* end = cursor;
            long difference = end - start - 1 - 3;
            char pageNumberArray[7] = {};
            char pageOffsetArray[4] = {};
            memcpy(pageNumberArray, start + 1, difference);
            memcpy(pageOffsetArray, cursor - 3, 3);
            pageNumberArray[6] = '\0';
            pageOffsetArray[3] = '\0';


            char abovePageArray[7] = {};
            char belowPageArray[7] = {};
            cursor = strstr(cursor, "TP =");
            start = cursor + 5;
            end = strstr(start, " ");
            memcpy(abovePageArray, start, end - start);

            cursor = strstr(cursor, "BP =");
            start = cursor + 5;
            end = strstr(start, "\n");
            memcpy(belowPageArray, start, end - start);


            uint32_t pageNumber = convertHexArrayToInt(pageNumberArray);
            uint32_t pageOffset = convertHexArrayToInt(pageOffsetArray);
            uint32_t abovePage = convertHexArrayToInt(abovePageArray);
            uint32_t belowPage = convertHexArrayToInt(belowPageArray);


            int pagePos = findPosition(pages, pageNumber);

            PageCandidate page = PageCandidate();
            if(pagePos == -1) {
                memset(&page, 0, sizeof(PageCandidate));
                page.pageNumber = pageNumber;
                page.abovePage = abovePage;
                page.belowPage = belowPage;
            }
            else {
                page = pages[pagePos];
                pages.erase(pages.begin() + pagePos);
            }



            for(int byte = 0; byte < 8; byte++) {
                uint8_t value = 16 * hex2int(bitsValue[2 * byte]) + hex2int(bitsValue[2 * byte + 1]);
                if(value != 0x00) {
                    for (int pos = 0; pos < 8; pos++) {
                        if (value & (0x01 << pos)) {
                            if(byte % 2 == 0) {
                                page.totalBitFlips++;
                                page.bitPositions[pos]++;
                            } else {
                                page.totalBitFlips++;
                                page.bitPositions[pos+8]++;
                            }
                        }
                    }
                }
            }

            pages.push_back(page);
        }
    }

    for(auto & page : pages) {
        PageCandidate p = page;
        calculateScore(p);
        page = p;
    }



    sort(pages.begin(), pages.end(), compareByScore);

    fclose(fptr);

}



void printPage(PageCandidate p, PageData pageData) {
    uint16_t* data = reinterpret_cast<uint16_t *>(p.pageVA);
    uint16_t* aboveData = reinterpret_cast<uint16_t *>(p.aboveVA[0]);
    uint16_t* belowData = reinterpret_cast<uint16_t *>(p.belowVA[0]);


    for(int i = 0; i < PAGE_SIZE / 2; i++) {
        printf("%i\t", pageData.data[i]);
        if(i % 8 == 7) {
            printf("\n");
        }
    }

    printf("\n");

    for(int off = 0; off < 512 * 4; off++) {
        printf("Address: %p\t", (data + off));
        printf("%i\t", *(data + off));
        if(off % 8 == 7) {
            printf("\n");
        }
    }
    printf("\n");
}








void rowhammer(uint8_t* aboveVA, uint8_t* belowVA, int iterations) {
    for(int i = 0; i < iterations; i++) {
        volatile uint64_t *f = (volatile uint64_t *)aboveVA;
        volatile uint64_t *s = (volatile uint64_t *)belowVA;
        unsigned long iters = TOGGLES;

        for(; iters --> 0;) {
            asm volatile("clflush (%0)" : : "r" (f) : "memory");
            *f;
            asm volatile("clflush (%0)" : : "r" (s) : "memory");
            *s;
        }
    }
}












void evaluatePageSuppressionData(PageCandidate p, PageSuppression &data, Pattern pattern) {
    uint16_t* startVA = reinterpret_cast<uint16_t*>(p.pageVA);


    for(int halfword = 0; halfword < (PAGE_SIZE / 2); halfword++) {
        uint16_t* halfwordData = startVA + halfword;

        for(int bit = 0; bit < 16; bit++) {
            uint16_t mask = 0x01 << bit;
            uint16_t bitData = *halfwordData & mask;



            if(bitData >= 1) {
                data.patternData[halfword][bit][pattern]++;
            }
        }
    }
}






void addVAstoPages(vector<PageCandidate> &pages, map<uint32_t, int> &pageMap, map<uint32_t, int> &aboveMap, map<uint32_t, int> &belowMap) {

    printf("Searching for page VAs...\n");
    uint8_t* moverVA = (uint8_t*) memory;
    while (moverVA < (((uint8_t*) memory) + mem_size)) {
        uint32_t moverPA = getPage(moverVA);
	    bool match = false;
        if(pageMap.count(moverPA) > 0) {
            int pageIndex = pageMap[moverPA];
            PageCandidate p = pages[pageIndex];
            match = true;

            p.pageVA = moverVA;
            pages[pageIndex] = p;
        }

        if(aboveMap.count(moverPA) > 0) {
            int aboveIndex = aboveMap[moverPA];
            PageCandidate p = pages[aboveIndex];
            match = true;

            if(moverVA == p.aboveVA[0] || p.aboveVA[0] == 0) {
                p.aboveVA[0] = moverVA;
            } else {
                p.aboveVA[1] = moverVA;
            }

            pages[aboveIndex] = p;
        }

        if(belowMap.count(moverPA) > 0) {
            int belowIndex = belowMap[moverPA];
            PageCandidate p = pages[belowIndex];
            match = true;

            if(moverVA == p.belowVA[0] || p.belowVA[0] == 0) {
                p.belowVA[0] = moverVA;
            } else {
                p.belowVA[1] = moverVA;
            }

            pages[belowIndex] = p;
        }

        if(!match) {
            munmap((void *) moverVA, PAGE_SIZE);
        }

        moverVA += 0x1000;
    }
    printf("Done searching...\n\n");
}

bool pagesFilled(PageCandidate p) {
    if(p.pageVA != 0 && p.aboveVA[0] != 0 && p.aboveVA[1] != 0 && p.belowVA[0] != 0 && p.belowVA[1] != 0) {
        return true;
    } else {
        return false;
    }
}

void countFlips(PageCandidate page, int flips[16]) {
    uint16_t* mover = reinterpret_cast<uint16_t*>(page.pageVA);
    for(int halfword = 0; halfword < PAGE_SIZE / 2; halfword++) {
        uint16_t* pos = mover + halfword;

        for(int bit = 0; bit < 16; bit++) {
            uint16_t mask = 0x1 << bit;
            uint16_t value = (*pos & mask);
            if(value > 0) {
                flips[bit]++;
            }
        } 
    }
}

void count256(PageCandidate page) {
    printf("Counting 256 flips\t");
    uint16_t* mover = reinterpret_cast<uint16_t*>(page.pageVA);
    for(int halfword = 0; halfword < PAGE_SIZE / 2; halfword++) {
        uint16_t* pos = mover + halfword;

        uint16_t mask = 0x1 << 8;
        uint16_t value = (*pos & mask);
        if(value > 0) {
            printf("%i\t", halfword);
        }
    }
    printf("\n");
}

int calculateRiskScore(int flips[16]) {
    int riskScore = 0;
    for(int i = MAX_POSITION; i < 16; i++) {
        riskScore += i * flips[i];
    }
    return riskScore;
}

void outputPage(PageCandidate page, PageData pageData) {
    FILE *pfile;
    string name = "data/V_";

    name = "data/V_";
    name.append(to_string(page.pageNumber));
    name.append(".txt");
    pfile = fopen(name.c_str(), "w");

    for(int halfword = 0; halfword < (PAGE_SIZE / 2); halfword++) {
        fprintf(pfile, "%i\t", pageData.data[halfword]);

        if(halfword % 8 == 7)
            fprintf(pfile, "\n");
    }
    fclose(pfile);

}


void collectPageData(PageCandidate page, PageData &pageData) {
    uint16_t* mover = reinterpret_cast<uint16_t*>(page.pageVA);
    for(int halfword = 0; halfword < PAGE_SIZE / 2; halfword++) {
        uint16_t value = (uint16_t) *(mover + halfword);
        pageData.data[halfword] += value;
    }
}




void profilePages(vector<PageCandidate> &pages) {
    printf("Total number of pages: %li\n\n", pages.size());

    for(int pageNumber = 0; pageNumber < pages.size(); pageNumber++) {
        PageCandidate page = pages[pageNumber];
        PageData  pageData = PageData();

        printf("Starting with page %i: %x\n", pageNumber, page.pageNumber);
        printf("Page score: %i\n", page.score);


        if(!pagesFilled(page)) {
            printf("Page VAs not found. Skipping page %i...\n\n", pageNumber);
            continue;
        }

        if(page.pageNumber != getPage(page.pageVA)) {
            printf("Converted VA to PA did not match expected PA.. Skipping...");
            continue;
        }

        fillMemory(page.pageVA, page.aboveVA[0], page.belowVA[0]);
        fillMemory(page.pageVA, page.aboveVA[1], page.belowVA[1]);


        int totalFlipsBefore[16] = {};
        for(int i = 0; i < TEST_ITERATIONS; i++) {
            usleep(TIME_BETWEEN_ITERATIONS);
            rowhammer(page.aboveVA[0], page.belowVA[0], HAMMER_ITERATIONS);
            countFlips(page, totalFlipsBefore);

            memset((void *) page.pageVA, 0x00, PAGE_SIZE);
        }



        printf("Running tests...\n");
        int totalFlips[16] = {};
        for(int i = 0; i < TEST_ITERATIONS; i++) {
            usleep(TIME_BETWEEN_ITERATIONS);
            rowhammer(page.aboveVA[0], page.belowVA[0], HAMMER_ITERATIONS);
            countFlips(page, totalFlips);
            count256(page);




            if(i != TEST_ITERATIONS - 1) {
                memset((void *) page.pageVA, 0x00, PAGE_SIZE);
            } else {
                collectPageData(page, pageData);
            }
        }
        printf("Ending tests...\n");


        printf("#: \t");
        for(int f = 0; f < 16; f++) {
            printf("%4i,\t", f);
        }
        printf("\n");
        printf("B: \t");
        for(int f = 0; f < 16; f++) {
            printf("%4i,\t", totalFlipsBefore[f]);
        }
        printf("\n");
        printf("A: \t");
        for(int f = 0; f < 16; f++) {
            printf("%4i,\t", totalFlips[f]);
        }
        printf("\n");


        int riskScore = calculateRiskScore(totalFlips);
        printf("Risk score for page is: %i\n", riskScore);

        if(riskScore <= RISK_THRESHOLD) {
            printf("Good page. Outputting...\n");

            outputPage(page, pageData);
        }


        memset((void *) page.pageVA, 0x00, PAGE_SIZE);

        printf("\n");
        printf("\n");

    }
    
}






int main(int argc, char *argv[]) {

    char* FILENAME;
    uint16_t INITIALOFFSET = 0;

    int opt;
    while ((opt = getopt(argc, argv, "f:o:")) != -1) {
        switch(opt) {
            case 'f':
                FILENAME=optarg;
                break;
        }
    }


    vector<PageCandidate> pages;

    setupMapping();


    getCandidatePages(FILENAME, pages);


    map<uint32_t, int> pageMap;
    map<uint32_t, int> aboveMap;
    map<uint32_t, int> belowMap;
    for(int i = 0; i < pages.size(); i++) {
        pageMap.insert(pair<uint32_t, int>(pages[i].pageNumber, i));

        aboveMap.insert(pair<uint32_t, int>(pages[i].abovePage, i));
        aboveMap.insert(pair<uint32_t, int>(pages[i].abovePage + 1, i));

        belowMap.insert(pair<uint32_t, int>(pages[i].belowPage, i));
        belowMap.insert(pair<uint32_t, int>(pages[i].belowPage + 1, i));
    }



    addVAstoPages(pages, pageMap, aboveMap, belowMap);


    profilePages(pages);







    return 0;
}
 
