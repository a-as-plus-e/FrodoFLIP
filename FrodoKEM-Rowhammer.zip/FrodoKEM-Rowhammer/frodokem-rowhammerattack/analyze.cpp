#include <stdio.h>
#include <stdint.h>

int main() {
   FILE *fp;
   int c;
   uint16_t E[640*8] = {};
  
   fp = fopen("./key/E.bin","r");
   fread(E, sizeof(uint16_t), 640*8, fp);

   for(int i = 0; i < 640 * 8; i++) {
      if(E[i] > 20 && E[i] < 30000) {
         printf("%i\t %i\n", i, E[i]);
      }
   } 


   fclose(fp);
   return(0);
}
