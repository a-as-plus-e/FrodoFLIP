#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <sched.h>

void *map_offset(const char *file, uint64_t offset) {
	  int fd = open(file, O_RDONLY);
	    if (fd < 0)
		        return NULL;

	      char *mapaddress = MAP_FAILED;
//#ifdef HAVE_MMAP64
	        mapaddress = mmap(0, sysconf(_SC_PAGE_SIZE), PROT_READ, MAP_PRIVATE, fd, offset & ~(sysconf(_SC_PAGE_SIZE) -1));
//#else
//		  mapaddress = mmap(0, sysconf(_SC_PAGE_SIZE), PROT_READ, MAP_PRIVATE, fd, ((off_t)offset) & ~(sysconf(_SC_PAGE_SIZE) -1));
//#endif
		    close(fd);
		      if (mapaddress == MAP_FAILED)
			          return NULL;
		        return (void *)(mapaddress+(offset & (sysconf(_SC_PAGE_SIZE) -1)));
}

int main(int argc, char **argv) {

	void *ff_ptr=NULL;

	ff_ptr = map_offset("./test", 0x115e);
	if(ff_ptr==NULL){
		printf("failed\n");
		exit(0);
	}

	for (;;) {
		asm volatile("clflush (%0)" : : "r" (ff_ptr) : "memory");
	}
}
			//delayloop(600);
			//        }
			//        }
			//
			//
