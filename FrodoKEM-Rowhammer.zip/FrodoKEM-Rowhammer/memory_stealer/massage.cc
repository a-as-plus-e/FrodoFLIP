#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include <linux/kernel-page-flags.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/types.h>
#include <sys/time.h>
#include <fcntl.h>
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unistd.h>
#include <math.h>
#include <regex>
#include <vector>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
 #include <stdlib.h>
#include <sys/sysinfo.h>
#include "massage.h"

#define PAGE_SIZE 4096

using namespace std;

uint64_t GetPhysAddr(uint8_t* virtual_address) {
  int pagemap = open("/proc/self/pagemap", O_RDONLY);
  assert(pagemap!=-1);
  // Read the entry in the pagemap.
  uint64_t value;
  int got = pread(pagemap, &value, 8,
                  (reinterpret_cast<uintptr_t>(virtual_address) / 0x1000) * 8);
  assert(got == 8);
  uint64_t page_frame_number = value & ((1ULL << 54)-1);
  assert(page_frame_number!=0);
  close(pagemap);
  return page_frame_number;
}


void *GetBlockByOrder(int order){
	size_t s=PAGE_SIZE*pow(2, order);
	void *ptr = mmap(NULL, s, PROT_READ | PROT_WRITE, MAP_POPULATE | MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
	
//	void *ptr=malloc(s);

	assert(ptr!= (void*)-1);
//

	//initialize pages
	for (uint64_t index = 0; index < s; index += 0x1000) {
		uint64_t* temporary = reinterpret_cast<uint64_t*>(static_cast<uint8_t*>(ptr) + index);
		temporary[0] = index+1;
	}
	return ptr;
}




size_t mem_size;
uint8_t* memory;
double fraction_of_physical_memory = 1.08;

// Obtain the size of the physical memory of the system.
uint64_t GetPhysicalMemorySize() {
    struct sysinfo info;
    sysinfo(&info);
    return (size_t) info.totalram * (size_t) info.mem_unit;
}

//Allocate large chunk of memory for finding correct pages
void setupMapping() {
    mem_size = (size_t) (((GetPhysicalMemorySize()) *
                          fraction_of_physical_memory));

    //mem_size = (size_t) PAGE_SIZE * 917504;
    printf("MemorySize: %zx\n", mem_size);  // prints as hex


    memory = (uint8_t *) mmap(NULL, mem_size, PROT_READ | PROT_WRITE,
                           MAP_POPULATE | MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);

    assert(memory != MAP_FAILED);

    memset((void *) memory, 0x00, mem_size);
}


int main(int argc, char **argv){
/*        cpu_set_t set;
        CPU_ZERO(&set);
        CPU_SET(1, &set);
        if(sched_setaffinity(getpid(), sizeof(set), &set) == -1)
            printf("Error in memory stealer set affinity...\n");
*/

	setupMapping();
	printf("Done allocating memory...");
/*
	uint8_t* moverVA = (uint8_t*) memory;
	while(moverVA < (( memory) + mem_size)) {
	    munmap((void *) moverVA, PAGE_SIZE);
	    moverVA += 0x1000;
	}

*/
	munmap((void *) memory, mem_size);
	printf("Done deallocating memory...");

	return 0;
}
