#ifndef MASSAGE_H
#define MASSAGE_H

void *GetBlockByOrder( int order);

void PrintPhysAddresses(void *ptr, int order);
int Get1gbBlock();
uint8_t *Get2mbBlock();
size_t GetNum1gbPages();
size_t GetNumFree1gbPages();
size_t GetNum2mbPages();
size_t GetNumFree2mbPages();

#endif
