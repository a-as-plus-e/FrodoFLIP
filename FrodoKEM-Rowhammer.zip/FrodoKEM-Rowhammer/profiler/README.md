run:

make rowhammer-sandy
sudo taskset 0x8 ./rowhammer-sandy -p 0.8 -d 1  > flip.txt 2>&1
