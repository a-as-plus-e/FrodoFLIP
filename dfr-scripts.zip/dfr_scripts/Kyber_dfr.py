from Kyber import *
from Kyber_failure import *
from proba_util import *

from functools import *


def transform_law(A, f):
    B = {}
    for x in A:
        y = f(x)
        B[y] = B.get(y, 0) + A[x]
    return B
    

    


def hammer_error_distribution(ps, hammer_pattern, dfr_type=0, adv_filter=threshold_law, **kwargs):
    '''
    hammer_pattern is a dictionary 
    '''
    
    # s secret key
    chis = build_centered_binomial_law(ps.ks)           # LWE error law for the key
    
    # hammer s
    chis_h = [hammer_law(chis, p) for p in hammer_pattern]
    
    n_hammer_coefs = sum(hammer_pattern.values())
    
    # e_1 and e_2
    chie = build_centered_binomial_law(ps.ke_ct)        # LWE error law for the ciphertext
    
    # e in public key, same as s
    chie_pk = build_centered_binomial_law(ps.ke)
    
    # c_t
    Rk = build_mod_switching_error_law(ps.q, ps.rqk)    # Rounding error public key
    
    # c_u
    Rc = build_mod_switching_error_law(ps.q, ps.rqc)    # rounding error first ciphertext
    
    # e + c_t
    chiRs = law_convolution(chis, Rk)                   # LWE+Rounding error key
    
    # e_1 + c_u
    chiRe = law_convolution(chie, Rc)                   # LWE + rounding error ciphertext
    
    # ( e + c_t) * r
    B1 = law_product(chie_pk, chiRs)                       # (LWE+Rounding error) * LWE (as in a E*S product)
    
    # s * (e_1 + c_u )
    B2 = law_product(chis, chiRe)
    
    B3 = []
    if honest:
        for i, p in enumerate(hammer_pattern):
            # s_h * (e_1 + c_u)
            B3.append( iter_law_convolution(law_product(chis_h[i], chiRe), hammer_pattern[p]) )
    else:
        B3 = []
        for i, p in enumerate(hammer_pattern):
            #e_1_a
            chie_a = adv_filter(chie, p, **kwargs) 
            # e_1a + c_u
            chiRe_a = law_convolution(chie_a, Rc)
            # s_h * (e_1a + c_u)
            B3.append( iter_law_convolution(law_product(chis_h[i], chiRe_a), hammer_pattern[p]) )
    
    C1 = iter_law_convolution(B1, ps.m * ps.n)
    
    C2 = iter_law_convolution(B2, ps.m * ps.n - n_hammer_coefs)

    C3 = reduce(law_convolution, B3)
    
    C = law_convolution(C1, C2)
    
    C = law_convolution_minus(C, C3)
    
    # c_v 
    R2 = build_mod_switching_error_law(ps.q, ps.rq2)    # Rounding2 (in the ciphertext mask part)
    
    # c_v + e_2
    F = law_convolution(R2, chie)                       # LWE+Rounding2 error
    
    D = law_convolution(C, F)                           # Final error
    
    return D

def error_probability(ps, **kwargs):
    D = hammer_error_distribution(ps, **kwargs)
    pr = tail_probability(D, ps.q/4)
    return pr
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    