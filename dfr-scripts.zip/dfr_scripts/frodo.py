from search_params_pke import estimate_cost

from approx_distr import approximate_dgauss

from discrete_distr import pdf_product, convolution, nfoldconvolution

from pqsec import svp_classical

from math import log

from proba_util import hammer_law, filter_distr

import numpy as np

class Frodo:
    def __init__(ps, n, m_bar, n_bar, agree_bits, sigma, qlog, B, lenX):
        ps.n = n
        ps.m_bar = m_bar
        ps.n_bar = n_bar
        ps.agree_bits = agree_bits
        ps.sigma = sigma
        ps.qlog = qlog
        ps.B = B
        ps.lenX = lenX
        
        ps.q = (1 << qlog)
        ps.required_coordinates = (agree_bits + B - 1) // B
        ps.samples = 2 * (m_bar + n_bar) * n + ps.required_coordinates
        
        #max_m = n + max(m_bar, n_bar)
        #c = estimate_cost( 1 << qlog, n, max_m, sigma, [svp_classical] ) [0]
        #ps.base_security = c - log(m_bar + n_bar) / log(2)
        
        #ps.chi = approximate_dgauss(sigma, ps.samples, ps.base_security, None, ps.lenX)[1]
        #ps.chi = pdf_product(ps.chi, {+1: .5, -1: .5})
        
        if n == 640:
            ps.chi_table = [9288, 8720, 7216, 5264, 3384, 1918, 958, 422, 164, 56, 17, 4, 1]
        elif n == 976:
            ps.chi_table = [11278, 10277, 7774, 4882, 2545, 1101, 396, 118, 29, 6, 1]
        elif n == 1344:
            ps.chi_table = [18286, 14320, 6876, 2023, 364, 40, 2]
        else:
            raise ValueError('unsupported parameter')
        
        ps.chi = {}
        for x, pr in enumerate(ps.chi_table):
            ps.chi[x] = ps.chi[-x] = 1.0*pr / (1 << 16)
            
        ps.T_chi = Frodo.__cdf_zero_centred_symmetric(ps.chi_table)
            
    @staticmethod
    def __cdf_zero_centred_symmetric(chi):
        T_chi = list(range(len(chi)))
        T_chi[0] = int(chi[0] / 2) - 1
        for z in range(1, len(chi)):
            T_chi[z] = T_chi[0] + sum(chi[1:z + 1])
        return T_chi
    
    def sample(self, r):
        """Sample from the error distribution using noise r (a two-byte array 
        encoding a 16-bit integer in little-endian byte order) (FrodoKEM 
        specification, Algorithm 5)"""
        # 1. t = sum_{i=1}^{len_x - 1} r_i * 2^{i-1}
        t = r >> 1
        # 2. e = 0
        e = 0
        # 3. for z = 0; z < s; z += 1
        for z in range(len(self.T_chi) - 1):
            # 4. if t > T_chi(z)
            if t > self.T_chi[z]:
                # 5. e = e + 1
                e += 1
        # 6. e = (-1)^{r_0} * e
        r0 = r % 2
        e = ((-1) ** r0) * e
        return e

    def sample_matrix(self, r, n1, n2):
        """Sample an n1 x n2 matrix from the error distribution using noise r 
        (FrodoKEM specification, Algorithm 6)"""
        E = [[None for j in range(n2)] for i in range(n1)]
        # 1. for i = 0; i < n1; i += 1
        for i in range(n1):
            # 2. for j = 0; j < n2; j += 1
            for j in range(n2):
                # 3. E[i][j] = Frodo.Sample(r^{i*n2+j}, T_chi)
                E[i][j] = self.sample(r[i * n2 + j])
        return E
    
    def sample_array(self, prg, n1, n2=None):
        if n2 is not None:
            E = np.empty((n1,n2), dtype=np.int16)
            for i in range(n1):
                for j in range(n2):
                    E[i,j] = self.sample(int.from_bytes(prg.bytes(2),'little'))
        else:
            E = np.empty(n1, dtype=np.int16)
            for i in range(n1):
                E[i] = self.sample(int.from_bytes(prg.bytes(2),'little'))
        
        return E
    
def FrodoPS(n):
    '''
    returns one of three Frodo parameter sets
    '''
    if n == 640:
        return Frodo(640, 8, 8, 128, 2.8, 15, 2, 16)
    if n == 976:
        return Frodo(976, 8, 8, 192, 2.3, 16, 3, 16)
    if n == 1344:
        return Frodo(1344, 8, 8, 256, 1.4, 16, 4, 16)
    raise ValueError('unsupported parameter')




def Frodo_hammer_dfr(ps, hammer_pattern, lower_t=None, upper_t=None):
    '''
    error = es' + s(-e') + e''
    
    General description:
    
    hammer_pattern is a dict of (p,f) -> k,
    where p is a 16-bit hammering pattern in s or e
    f is filter function used to filter corresponding entries in s' or e'
    Let f = None in honest case.
    k is the number of coeffients in s or e affected by p, which equals the number of coefficients in s' or e' affected by f
    
    How p is represented:
    
    Consider a column of 640 16-bit coefficients.
    Say we force the (0th, 2nd, 5th) bits, of 3 out of those 640 coeffs, to be 1.
    Then, p is represented as integer 2^0 + 2^2 + 2^5 = 37.
    In that case, hammer_pattern dict has an item (37, f) -> 3.
    If those same bits are forced to 0 instead of 1, then hammer_pattern has (-37, f) -> 3.
    
    If within a single 16-bit coeff, some bits are forced to 0 and some 1; e.g.
    the 0th and 2th bits are forced to 1, and the 1st and 3rd bits are forced 0,
    then p is a tuple (5, -9) instead of a single integer.
    
    How do define f:
    f is a function that takes as input an integer and returns True or False.
    For Frodo640, the input integer is in range [-12, 12], Frodo976 [-10, 10], Frodo1344 [-6, 6].
    
    '''
    
    A = {0: 1} # distr of S'E
    for (p, f), k in hammer_pattern.items():
        chi_h = hammer_law(ps.chi, p)
        if callable(f):
            chi_f = filter_distr(ps.chi, f)
        else:
            chi_f = ps.chi
        A = convolution(A, nfoldconvolution(k, pdf_product(chi_h, chi_f, ps.q), ps.q), ps.q)
        
    n_unhammered = 2*ps.n - sum(hammer_pattern.values())
    
    B = nfoldconvolution(n_unhammered, pdf_product(ps.chi, ps.chi ,ps.q), ps.q)
    
    D = convolution(A, B, ps.q) # distr of S'E - E'S
    
    E = convolution(D, ps.chi, ps.q) # distr of E'''
    
    pr = 0
    b = ps.q / (2 ** ps.B)
    if lower_t == None:
        lower_t = -b/2
    if upper_t == None:
        upper_t = b/2
    for x, p in E.items():
        #y = min(x, ps.q - x)
        y = x if x < ps.q / 2 else x - ps.q
        if not (lower_t <= y < upper_t):
            pr += p
            
    return pr
    